/*
==============================
spark-shell --master local[*]
==============================
Word count example for RDD
==========================
*/

val lines = sc.textFile("sparkinput/war_and_peace.txt",3)
lines // To get the type of the val lines

lines.getNumPartitions
lines.mapPartitions(iter => Iterator(iter.size), true).collect()

lines.count()
lines.take(5)

val nonNullLines = lines.filter(line => line.length>0)
nonNullLines.count()
nonNullLines.take(5)

val words = nonNullLines.flatMap(line => line.split(" ") )
words.count()
words.take(5)

val upperWords = words.map(word => word.toUpperCase)
upperWords.count()
upperWords.take(5)

val pairedOnes = upperWords.map(uw => (uw, 1))
pairedOnes.count()
pairedOnes.take(5)

val wordCounts = pairedOnes.reduceByKey(_ + _)
wordCounts.count()
wordCounts.take(5)
wordCounts.take(5).foreach(println)

// val wordCounts = pairedOnes.reduceByKey( (x, y) => x + y)
