/*
==============================
spark-shell --master local[*]
==============================
linear regression 1
====================
*/

import org.apache.spark.sql.SparkSession

import org.apache.spark.ml.regression.LinearRegression
import org.apache.spark.ml.feature.VectorAssembler
import org.apache.spark.ml.feature.StandardScaler

val data = spark.read.format("csv").option("sep", ",").option("inferSchema", "true").option("header","true").load("sparkinput/linregdata1.csv")
data.printSchema()

val features = Array("temperature", "exhaust_vacuum", "ambient_pressure", "relative_humidity")

val lr_data = data.select(col("energy_output").alias("label"), col("temperature"), col("exhaust_vacuum"), col("ambient_pressure"), col("relative_humidity"))
lr_data.printSchema()
lr_data.show(5)

val vectorAssembler = new VectorAssembler().setInputCols(features).setOutputCol("unscaled_features")
// val vectorAssembler = new VectorAssembler().setInputCols(Array("temperature", "exhaust_vacuum", "ambient_pressure", "relative_humidity")).setOutputCol("unscaled_features")
val va_data = vectorAssembler.transform(lr_data)
va_data.printSchema()
va_data.show(false)

val standardScaler = new StandardScaler().setInputCol("unscaled_features").setOutputCol("features")
val ss_data = standardScaler.fit(va_data).transform(va_data)
// val ss_model = standardScaler.fit(va_data)
// val ss_data = ss_model.transform(va_data)
ss_data.printSchema()
ss_data.show(false)

val Array(training, test) = ss_data.randomSplit(Array(.7, .3))
training.describe().show()
test.describe().show()

val lr = new LinearRegression().setMaxIter(10).setRegParam(0.1)

val lr_model = lr.fit(training)

lr_model.coefficients
lr_model.intercept

val prediction_df = lr_model.transform(test)

prediction_df.show(false)
prediction_df.select("label","prediction").show(false)

import org.apache.spark.ml.evaluation.RegressionEvaluator

val eval = new RegressionEvaluator().setLabelCol("label").setPredictionCol("prediction").setMetricName("rmse")

val rmse = eval.evaluate(prediction_df)
val mse = eval.setMetricName("mse").evaluate(prediction_df)
val mae = eval.setMetricName("mae").evaluate(prediction_df)
val r2 = eval.setMetricName("r2").evaluate(prediction_df)

// // // 
// Saving the model
lr_model.write.overwrite().save("saved_lr_model")


import org.apache.spark.ml.regression.LinearRegressionModel

// Load the saved model
val loaded_lr_model = LinearRegressionModel.load("saved_lr_model")

// Applying the model on the new records

val newlinreg_df = spark.read.format("csv").option("sep", ",").option("inferSchema", "true").option("header","true").load("file:///home/unextnovuser022/sparksql/newlinreg.csv")
newlinreg_df.show()

val newva_data = vectorAssembler.transform(newlinreg_df)
newva_data.show()

val newss_data = standardScaler.fit(newva_data).transform(newva_data)
newss_data.show()

val newprediction_df = loaded_lr_model.transform(newss_data)

newprediction_df.printSchema()

newprediction_df.show()
newprediction_df.select("temperature", "exhaust_vacuum", "ambient_pressure", "relative_humidity", "prediction").show()
