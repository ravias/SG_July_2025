import org.apache.spark.sql.SparkSession

object DataFrames {
  def main(args: Array[String]) {

    val master=args(0)
    val customersfile=args(1)
    val productsfile=args(2)
    val outputlocation=args(3)

    val spark = SparkSession.builder.master(master).appName("Spark SQL basic example").getOrCreate()

    val customerDF = spark.read.format("csv").option("sep", "\t").option("inferSchema", "true").option("header","true").load(customersfile)

    customerDF.createOrReplaceTempView("customers")

    customerDF.show(5)

    val productDF = spark.read.format("json").load(productsfile)

    productDF.createOrReplaceTempView("products")

    productDF.show(5)

/*
Now that we have two datasets in two views we can join them on the common column for queries. For example:
Get the list of customers and product categories in which they bought multiple items (quantity) that are more expensive than 200.00
*/

    val custlist200 = spark.sql("SELECT a.customer_name, b.product_category, count(*) as prdcount FROM customers a INNER JOIN products b ON a.customer_id=b.customer_id WHERE b.product_price>200.00 GROUP BY a.customer_name, b.product_category HAVING prdcount>1")

    custlist200.coalesce(1).write.format("csv").option("sep", "\t").option("header","true").save(outputlocation)

    custlist200.show(5)
    println(s"\n\n***** Saved the file in ${outputlocation} *****\n\n")
    spark.stop()
  }
}
