$ mysql -hdatabase.claas.cloudlab.com -uclaasuser_read -p"2KD4nPDnyrZ@5jUKH"

$ spark2-shell --master local[*] --driver-class-path /usr/share/java/mysql-connector-java.jar --jars /usr/share/java/mysql-connector-java.jar

spark-shell --master local[*] --driver-class-path /opt/hive-3.1.1/lib/mysql-connector-java-8.0.26.jar --jars /opt/hive-3.1.1/lib/mysql-connector-java-8.0.26.jar

scala>
scala>
val jdbcDF1 = spark.read.format("jdbc").option("url", "jdbc:mysql://master").option("dbtable", "unextnovuser022.customers").option("user", "unextnovuser022").option("password", "Nuvelabs123$").load()

jdbcDF1.printSchema()
jdbcDF1.show()
jdbcDF1.count()

val jdbcDF2 = spark.read.format("jdbc").option("url", "jdbc:mysql://master").option("dbtable", "unextnovuser022.products").option("user", "unextnovuser022").option("password", "Nuvelabs123$").load()

jdbcDF2.printSchema()
jdbcDF2.show()
jdbcDF2.count()

// Using Properties
import java.util.Properties

val connectionProperties = new Properties()
connectionProperties.put("user", "unextnovuser022")
connectionProperties.put("password", "Nuvelabs123$")

val jdbcDF3 = spark.read.jdbc("jdbc:mysql://master", "unextnovuser022.customers", connectionProperties)

jdbcDF3.printSchema()
jdbcDF3.show()
jdbcDF3.count()

// Saving data to a JDBC source
// The user needs to have write i.e. create table permissions to the database

val peopleDF = spark.read.format("csv").option("inferSchema", "true").load("sparkinput/people.txt")
val peopleDF2=peopleDF.withColumnRenamed("_c0","name").withColumnRenamed("_c1","age")

peopleDF2.write.format("jdbc").option("url", "jdbc:mysql://master").option("dbtable", "unextnovuser022.people").option("user", "unextnovuser022").option("password", "Nuvelabs123$").save()

peopleDF2.write.jdbc("jdbc:mysql://master", "unextnovuser022.people2", connectionProperties)
