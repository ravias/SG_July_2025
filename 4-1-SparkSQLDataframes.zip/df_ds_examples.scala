case class cust_cc (customer_id: Long, customer_name: String, customer_city: String, customer_state: String, customer_zipcode: String)

val cust_ds = spark.read.format("csv").option("sep", "\t").option("inferSchema", "true").option("header","true").load("sparkdata/customers.txt").as[cust_cc]

cust_ds.filter(c => c.customer_state=="CA").show()
cust_ds.filter(c => c.customer_district=="CA").show()
cust_ds.rdd
val cust_count=cust_ds.filter(c=>{c.customer_state=="CA"}).map(c=>(c.customer_state, c.customer_zipcode)).groupBy($"_2").count()
cust_count.show()


val cust_df = spark.read.format("csv").option("sep", "\t").option("inferSchema", "true").option("header","true").load("sparkdata/customers.txt")
cust_df.filter($"customer_state"==="CA").show
cust_df.filter($"customer_district"==="CA").show
cust_df.rdd


// **************************
// Creating DataSets

case class Person(name: String, age: Int)

// Create an RDD of Person objects and convert it to a dataframe
val people = sc.textFile("sparkinput/people.txt").map(_.split(",")).map(p => Person(p(0), p(1).trim.toInt)).toDF()

val peopleDS = people.as[Person]

people.filter("age > 25").show()
people.filter("salary > 10000").show()

// The error from above line in dataframe is captured only at run time.
// Because the code is referring to data attributes by name, it is not possible for the compiler to catch any errors.
// If attribute names are incorrect then the error will only detected at runtime, when the query plan is created.

peopleDS.filter(p => p.age > 25)
peopleDS.filter(p => p.salary > 25)

// The error from above line in dataset is captured at the compile time.

